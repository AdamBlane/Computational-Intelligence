package coursework;

import model.Gui;

public class StartGui {

	/**
	 * Starts the Gui Application
	 * 
	 */
	public static void main(String[] args) {
		Gui.main(null);
	}

}
